package fr.emn.gestion_colocation.presentation;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;

import javax.swing.SwingConstants;

import fr.emn.gestion_colocation.abstraction.Colocation;

public class RemboursementDialog extends JDialog {

	private static final long serialVersionUID = 1L;
	public static final int LABEL_SIZE = 17;

	Vector<String> allRemboursements = new Vector<String>();

	public RemboursementDialog(Frame parent, Colocation modele) {
		super(parent, "Remboursements", true);


		this.getContentPane().setLayout(new BorderLayout());
		this.creerBas();
		this.creerCentre();
		this.pack();
		this.setLocationRelativeTo(this.getParent());
	}
	
	private void creerCentre() {
		JPanel panneauCentre = new JPanel();
		panneauCentre.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 20));
		panneauCentre.setLayout(new BoxLayout(panneauCentre, BoxLayout.Y_AXIS));

		// - titre
		JLabel labelLesRemboursements = new JLabel("Remboursements � effectuer",SwingConstants.CENTER);
		labelLesRemboursements.setFont(new Font(labelLesRemboursements.getFont().getName(), Font.BOLD, LABEL_SIZE));
		panneauCentre.add(labelLesRemboursements, BorderLayout.NORTH);

		for(int i=0; i<6; i++ ) {
			final JCheckBox check = new JCheckBox("bmenou12 doit 2 � � cloise12");
			panneauCentre.add(check, BorderLayout.CENTER);
			check.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					check.setEnabled(false);
				}
			});
		}
		this.getContentPane().add(panneauCentre, BorderLayout.WEST);

	}

	private void creerBas() {
		JPanel panneauSud = new JPanel(new BorderLayout());
		panneauSud.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

		// - titre
		JLabel labelLesRemboursements = new JLabel("Valider la suppression des dettes",SwingConstants.CENTER);
		labelLesRemboursements.setFont(new Font(labelLesRemboursements.getFont().getName(), Font.PLAIN, 17));
		panneauSud.add(labelLesRemboursements, BorderLayout.NORTH);

		// - bouton
		RoundButton reset = new RoundButton(new ImageIcon("images"+File.separator+"valider.png"));
		reset.setToolTipText("Suppression des dettes");
		panneauSud.add(reset);
		this.getContentPane().add(panneauSud, BorderLayout.SOUTH);

		reset.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
			}
		});

	}


}
