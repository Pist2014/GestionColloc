package fr.emn.gestion_colocation.abstraction;

import java.util.Date;

public class Depense {

	/*-----------------------------------------------------------------------------------------
	 *                                    VARIABLES D'INSTANCES
	 *----------------------------------------------------------------------------------------- */
	
	private String nom;
	private float montant;
	private Date date;
	private boolean alimentaire; // pour le prix moyen du repas
	private Colocataire colocataire;
	
	/*-----------------------------------------------------------------------------------------
	 *                                    CONSTRUCTEURS
	 *----------------------------------------------------------------------------------------- */

	public Depense(String nom, float montant, Date date, boolean alimentaire, Colocataire colocataire) {
		super();
		this.nom = nom;
		this.montant = montant;
		this.date = date;
		this.alimentaire = alimentaire;
		this.colocataire = colocataire;
	}
	
	/*-----------------------------------------------------------------------------------------
	 *                                    SERVICES
	 *----------------------------------------------------------------------------------------- */
	
	public String getNom() {
		return this.nom;
	}
	
	public void setNom(String nom) {
		this.nom = nom;
	}
	
	public float getMontant() {
		return this.montant;
	}

	public void setMontant(float montant) {
		this.montant = montant;
	}

	public Colocataire getColocataire() {
		return this.colocataire;
	}

	public void setColocataire(Colocataire colocataire) {
		this.colocataire = colocataire;
	}

	public Date getDate() {
		return this.date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public boolean isAlimentaire() {
		return this.alimentaire;
	}

	public void setAlimentaire(boolean alimentaire) {
		this.alimentaire = alimentaire;
	}
	
}
