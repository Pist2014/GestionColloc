package fr.emn.gestion_colocation.abstraction;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Vector;

public class ColocationJDBC extends Colocation {
	
	/**
	 * Constructeur �tablissant la connexion � la base de donn�es
	 * et initialise stmt
	 */
	public ColocationJDBC() {
	}

	@Override
	public Vector<String> findAllRemboursements() {
		// TODO Auto-generated method stub
		return null;
	}

}
