package fr.emn.gestion_colocation.abstraction;

public class Remboursements {

	/*-----------------------------------------------------------------------------------------
	 *                                    VARIABLES D'INSTANCES
	 *----------------------------------------------------------------------------------------- */

	private double[][] dettes;

	/*-----------------------------------------------------------------------------------------
	 *                                    CONSTRUCTEURS
	 *----------------------------------------------------------------------------------------- */

	public Remboursements (double[][] dettes) {
		this.dettes = dettes;
	}

	/*-----------------------------------------------------------------------------------------
	 *                                    SERVICES
	 *----------------------------------------------------------------------------------------- */

	public double[][] getDette() {
		return this.dettes;
	}

	public double getDette(int i, int j) {
		return this.dettes[i][j];
	}

	public void setDette(int i, int j, double dette) {
		this.dettes[i][j] = dette;
	}

	public String toString() {
		String res = "";
		for(int i=0; i<this.getDette().length; i++){
			for(int j=0; j<this.getDette().length; j++){
				res = res+this.getDette(i, j)+"  ";
			}
			res = res+"\n";
		}
		return  res;
	}

	public double getEntrees(int j) {
		double res = 0;
		for(int i=0; i<this.getDette().length; i++) {
			res += this.getDette(i, j);
		}
		return res;
	}

	public double getSorties(int i) {
		double res = 0;
		for(int j=0; j<this.getDette().length; j++) {
			res += this.getDette(i, j);
		}
		return res;
	}

	public boolean isDeficitaire(int i) {
		return this.getEntrees(i)-this.getSorties(i)<0;
	}

	public boolean isBeneficiaire(int j) {
		return this.getEntrees(j)-this.getSorties(j)>0;
	}

	public Remboursements simplification() {
		for(int i=0; i<this.getDette().length; i++){
			for(int j=0; j<this.getDette().length; j++){
				if(this.getDette(i, j) !=0 && this.getDette(j, i) !=0){
					if(this.getDette(i, j) > this.getDette(j, i)) {
						this.setDette(i, j, this.getDette(i, j)-this.getDette(j, i));
						this.setDette(j, i, 0);
					}
					if(this.getDette(i, j) < this.getDette(j, i)) {
						this.setDette(i, j, this.getDette(j, i)-this.getDette(i, j));
						this.setDette(i, j, 0);
					}
					if(this.getDette(i, j) == this.getDette(j, i)) {
						this.setDette(j, i, 0);
						this.setDette(i, j, 0);
					}
				}
			}
		}
		return this;
	}

	public String aide() {
		String res = "";
		for(int i=0; i<this.getDette().length; i++){
			if(this.getEntrees(i)-this.getSorties(i)>0){
				res += "Le colocataire "+(i+1)+" doit recevoir "+(this.getEntrees(i)-this.getSorties(i))+" �"+"\n";
			}
			else {
				res += "Le colocataire "+(i+1)+" doit donner "+(-this.getEntrees(i)+this.getSorties(i))+" �"+"\n";
			}
		}
		return res;
	}


	public Remboursements remboursementOptimal(int nbColocataires) {
		Remboursements res = new Remboursements(new double[nbColocataires][nbColocataires]); 

		double[] debitRestant = new double[nbColocataires];
		double[] creditRestant = new double[nbColocataires];

		for(int k=0; k<nbColocataires; k++){
			if(this.isBeneficiaire(k)) {
				debitRestant[k] = 0;
				creditRestant[k] = this.getEntrees(k)-this.getSorties(k);
			}

			if(this.isDeficitaire(k)) {
				debitRestant[k] = this.getSorties(k)-this.getEntrees(k);
				creditRestant[k] = 0 ;
			}	
		}

		for(int i=0; i<this.getDette().length; i++){
			if(debitRestant[i]-creditRestant[i]>0) {
				int j=0; 
				while(debitRestant[i]!=0){
					if(j!=i){
						if(debitRestant[j]-creditRestant[j]<0) {

							if(creditRestant[j]!=0){

								if(debitRestant[i]<=creditRestant[j]){
									res.setDette(i, j, debitRestant[i]);
									creditRestant[j] -= debitRestant[i];
									debitRestant[i] = 0;
								}

								if(debitRestant[i]>creditRestant[j]){
									res.setDette(i, j, creditRestant[j]);
									creditRestant[j] = 0;
									debitRestant[i] -= creditRestant[j];
								}
							}
						}
						j++;
					}
				}
			}
		}
		return res;
	}

	public String bilan() {
		String res = "";
		for(int i=0; i<this.getDette().length; i++){
			for(int j=0; j<this.getDette().length; j++){
				if(this.getDette(i, j)!=0){
					res += "Le colocataire "+(i+1)+" doit "+this.getDette(i, j)+" � au colocataire "+(j+1)+"\n";
				}
			}
		}
		return res;
	}

	public static void main(String[] args) {
		int nbColocataires = 4;
		double[][] dettes = new double[nbColocataires][nbColocataires];
		dettes[0][0] = 0;
		dettes[0][1] = 2;
		dettes[0][2] = 0;
		dettes[0][3] = 4;
		dettes[1][0] = 1;
		dettes[1][1] = 0;
		dettes[1][2] = 4;
		dettes[1][3] = 0;
		dettes[2][0] = 3;
		dettes[2][1] = 0;
		dettes[2][2] = 0;
		dettes[2][3] = 1;
		dettes[3][0] = 4;
		dettes[3][1] = 1;
		dettes[3][2] = 1;
		dettes[3][3] = 0;


		Remboursements test = new Remboursements(dettes);

		System.out.println(test);

		System.out.println(test.simplification());
		System.out.println(test.aide());

		System.out.println(test.remboursementOptimal(nbColocataires));
		System.out.println(test.remboursementOptimal(nbColocataires).bilan());
	}
}

