package fr.emn.gestion_colocation.abstraction;


import java.io.File;
import java.io.IOException;
import java.util.Observable;
import java.util.Vector;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

	public abstract class Colocation extends Observable {
		

		public Colocation() {
			super();
		}
		
		public abstract Vector<String> findAllRemboursements();

		
		protected class ImportException extends Exception {

			private static final long serialVersionUID = 1L;
			
			public ImportException(){
				super();
			}
			
		}

	}
